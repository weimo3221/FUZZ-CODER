#MP3Gain

MP3Gain analyzes and losslessly adjusts mp3 files to a specified target volume.
It does not simply do peak amplitude normalization.
Instead, it performs statistical analysis to determine how loud the file actually sounds to the human ear.

#Author

Glen Sawyer

#Homepage

https://sourceforge.net/projects/mp3gain/
