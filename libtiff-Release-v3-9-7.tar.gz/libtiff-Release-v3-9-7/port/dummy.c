/* $Id$ */

/*
 * Dummy function, just to be ensure that the library always will be created.
 */

void
libport_dummy_function()
{
        return;
}

/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 8
 * fill-column: 78
 * End:
 */
