//========================================================================
//
// SplashFontFileID.cc
//
//========================================================================

#include <config.h>

#ifdef USE_GCC_PRAGMAS
#pragma implementation
#endif

#include "SplashFontFileID.h"

//------------------------------------------------------------------------
// SplashFontFileID
//------------------------------------------------------------------------

SplashFontFileID::SplashFontFileID() {
}

SplashFontFileID::~SplashFontFileID() {
}
